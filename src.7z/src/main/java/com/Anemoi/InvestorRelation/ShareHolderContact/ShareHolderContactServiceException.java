package com.Anemoi.InvestorRelation.ShareHolderContact;

public class ShareHolderContactServiceException extends Exception {
	
	private static final long SerialVertionUID=1L;

	public ShareHolderContactServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ShareHolderContactServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ShareHolderContactServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ShareHolderContactServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ShareHolderContactServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
