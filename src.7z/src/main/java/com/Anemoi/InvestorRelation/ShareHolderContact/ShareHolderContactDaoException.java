package com.Anemoi.InvestorRelation.ShareHolderContact;

public class ShareHolderContactDaoException extends Exception{
	
	private static final long SerialVertionUID=1L;

	public ShareHolderContactDaoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ShareHolderContactDaoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ShareHolderContactDaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ShareHolderContactDaoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ShareHolderContactDaoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
