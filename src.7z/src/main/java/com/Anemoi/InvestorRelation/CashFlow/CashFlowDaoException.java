package com.Anemoi.InvestorRelation.CashFlow;

public class CashFlowDaoException extends Exception {
	
	private static final long SerialVertionUID=1L;

	public CashFlowDaoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CashFlowDaoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CashFlowDaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CashFlowDaoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CashFlowDaoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
