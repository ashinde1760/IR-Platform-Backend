package com.Anemoi.InvestorRelation.DataIngestion;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import io.micronaut.http.multipart.CompletedFileUpload;

public interface DataIngestionDao {
	

	DataIngestionModel saveDataIngestionDetails(DataIngestionModel dataIngestionModel, String dataBaseName) throws SQLException,DataIngestionDaoException;
	
	String saveDataIngestionInDataBase(DataIngestionModel dataIngestion, String dataBaseName) throws SQLException, FileNotFoundException, IOException, ClassNotFoundException,DataIngestionDaoException;

	
	ArrayList<TableList> getTableIdByFileId(long fileId, String dataBaseName)	throws DataIngestionDaoException;
	
	
	ArrayList<DataIngestionTableModel> getTableIngestionTableData(long tableId, String dataBaseName) throws DataIngestionDaoException;

	ArrayList<DataIngestionTableModel> updatedataIngestionTableData(ArrayList<DataIngestionTableModel> dataIngestionTableData, long tableId,
			String dataBaseName) throws DataIngestionDaoException;
	
	void deleteTableDataByTableId(long tableId, String dataBaseName) throws DataIngestionDaoException;


	ArrayList<DataIngestionMappingModel> addDataIngestionMappingTableData(ArrayList<DataIngestionMappingModel> dataIngestionMappingTable,
			String dataBaseName) throws DataIngestionDaoException;

	DataIngestionTableModel getTableDataByFeldId(long field_Id, String dataBaseName) throws DataIngestionDaoException;

	void deleteTableDataByFieldId(long field_Id, String dataBaseName) throws DataIngestionDaoException;

	TableList updateTableNameByTableId(TableList tabledata,long tableId, String dataBaseName) throws DataIngestionDaoException;

	String downloadTableDataBytableId(long tableId, String dataBaseName) throws DataIngestionDaoException, IOException;

	ArrayList<DataIngestionModel> getfileDetails(String dataBaseName) throws DataIngestionDaoException;

	ArrayList<KeywordList> getKeyword(String dataBaseName);

	String uploadExcelSheet(CompletedFileUpload file, long tableId, String dataBaseName);




	


	


  
	
}
