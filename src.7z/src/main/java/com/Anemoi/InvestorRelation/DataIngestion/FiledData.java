package com.Anemoi.InvestorRelation.DataIngestion;

import java.util.ArrayList;

public class FiledData {
	
	private ArrayList<Long> field_Id;

	public ArrayList<Long> getField_Id() {
		return field_Id;
	}

	public void setField_Id(ArrayList<Long> field_Id) {
		this.field_Id = field_Id;
	}

	public FiledData(ArrayList<Long> field_Id) {
		super();
		this.field_Id = field_Id;
	}

	public FiledData() {
		super();
	}
	

	
	

}
