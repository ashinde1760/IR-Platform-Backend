package com.Anemoi.InvestorRelation.DataIngestion;


import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.Anemoi.InvestorRelation.CashFlow.CashFlowDaoException;
import com.Anemoi.InvestorRelation.Configuration.InvestorDatabaseUtill;
import com.Anemoi.InvestorRelation.Configuration.ReadPropertiesFile;
import com.azure.ai.formrecognizer.DocumentAnalysisClient;
import com.azure.ai.formrecognizer.DocumentAnalysisClientBuilder;
import com.azure.ai.formrecognizer.models.AnalyzeResult;
import com.azure.ai.formrecognizer.models.DocumentOperationResult;
import com.azure.ai.formrecognizer.models.DocumentTable;
import com.azure.ai.formrecognizer.models.DocumentTableCell;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.core.util.polling.SyncPoller;

import io.micronaut.http.multipart.CompletedFileUpload;
import jakarta.inject.Singleton;

@Singleton
public class DataIngestionDaoImpl implements DataIngestionDao {
	

	private static long tableid;
  
    private static long fileId;
	private static final Logger LOGGER = LoggerFactory.getLogger(DataIngestionDaoImpl.class);
	HSSFWorkbook workbook = new HSSFWorkbook();
   
	@SuppressWarnings("resource")
	@Override
	public DataIngestionModel saveDataIngestionDetails(DataIngestionModel dataIngestionModel, String dataBaseName) throws DataIngestionDaoException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement psta = null;
		Date date = new Date();
		ResultSet rs=null;
	
		try {
	   System.out.println("file id"+fileId);
			System.out.println("file name" +dataIngestionModel.getFileName());
		

			connection = InvestorDatabaseUtill.getConnection();
	
			psta=connection.prepareStatement(DataIngestionQueryConstant.SELECT_MAX_FILEID.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER,dataBaseName));
		
			rs=psta.executeQuery();
			while(rs.next())
			{  
				
				long maxvalue=rs.getLong(1);
				
		
			fileId=maxvalue;
			System.out.println("file Id"+fileId);
			psta = connection.prepareStatement(DataIngestionQueryConstant.INSERT_INTO_DATA_INGESTION
					.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
		//			String fileId = UUID.randomUUID().toString();
			dataIngestionModel.setFileId(fileId+1);
			psta.setLong(1,dataIngestionModel.getFileId());
			psta.setString(2, dataIngestionModel.getClient());
			psta.setString(3, dataIngestionModel.getDocumentType());
			psta.setString(4, dataIngestionModel.getAnalystName());
			psta.setDate(5,dataIngestionModel.getReportFrom());
			psta.setDate(6, dataIngestionModel.getReportTo());
			psta.setString(7, dataIngestionModel.getFileName());
			psta.setString(8, dataIngestionModel.getFileType());
			psta.setBytes(9, dataIngestionModel.getFileData());
			psta.executeUpdate();
			
			
			
			}
			
			return dataIngestionModel;
		
			
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			throw new DataIngestionDaoException("unable to create data Ingestion model"+e.getMessage());
		} finally {
			LOGGER.info("closing the connection");
			InvestorDatabaseUtill.close(psta, connection);

		}
	
	}

	


	@Override
	public String saveDataIngestionInDataBase(DataIngestionModel dataIngestion, String dataBaseName) throws SQLException, IOException, ClassNotFoundException,DataIngestionDaoException {
		// TODO Auto-generated method stub
		System.out.println("check1");
		PreparedStatement statement=null;
		ResultSet rs=null;
		ArrayList<DataIngestionTableModel> modellist=new ArrayList<>();
		
		
		XSSFRow row;
		String extPattern = "(?<!^)[.]" + (".*");

		final String endpoint = "https://secondformrecognizer001.cognitiveservices.azure.com/";
		final String key = "8a2c1038c4ee4c87ace5fb24723f3396";
		DocumentAnalysisClient client = new DocumentAnalysisClientBuilder().credential(new AzureKeyCredential(key))
				.endpoint(endpoint).buildClient();

		//	String modelId = "54a23747-5d44-475d-a3d1-e7b18f047a90";
		String modelId = "prebuilt-document";
		//String FileName = "C:\\Users\\DELL\\Desktop\\IR DOC\\infosys.pdf";
//		String FileName = "C:\\Users\\DELL\\Desktop\\IR DOC\\all documents for OCR\\Splitted Doc\\infosis.pdf";
	//	String FileName = "C:\\Users\\DELL\\Desktop\\IR DOC\\all documents for OCR\\Sample Documents\\Analyst Data\\Infosys\\Emkay\\Q1 results.pdf";
         String fileName=dataIngestion.getFileName();
		File document = new File(fileName);
		XSSFWorkbook workbook = new XSSFWorkbook();

		String replacedFileName = document.getName().replaceAll(extPattern, "");
		System.out.println(replacedFileName + " replaced name");

		byte[] fileContent = dataIngestion.getFileData();

		try (InputStream targetStream = new ByteArrayInputStream(fileContent)) {

			SyncPoller<DocumentOperationResult, AnalyzeResult> analyzeDocumentPoller = client
					.beginAnalyzeDocument(modelId, targetStream, (fileContent.length));

			AnalyzeResult analyzeResult = analyzeDocumentPoller.getFinalResult();
			String content=	analyzeResult.getContent().toString();
			ArrayList<String> list=new ArrayList<>();
			list.add(content);
			//System.out.println(list);
			//for (int p = 0; p <list.size(); p++) {
				
			//String a=list.get(p);
			//System.out.println(a);
			//if(a.contains("Key Financials (Consolidated) Income Statement"))
			//{
			int incomeSheetCount=1;
			int balanceSheetCount=1;
			int cashFlowCount=1;
			int sheetcount=1;
		
			List<DocumentTable> tables = analyzeResult.getTables();      
			for (int i = 0; i < tables.size(); i++) {

				DocumentTable documentTable = tables.get(i);

				System.out.printf("Table %d has %d rows and %d columns.%n", i, documentTable.getRowCount(),
						documentTable.getColumnCount());

				XSSFSheet spreadsheet = workbook.createSheet("sheet");
				XSSFRow newrow = spreadsheet.createRow(0);

				int count = 0;
				int col = 0;

			//	ArrayList<WeightedWord> keyWords = fetchWeighteWords();
				
				
				for (DocumentTableCell documentTableCell : documentTable.getCells()) {
					int rowIndex = documentTableCell.getRowIndex();

					if (count < rowIndex) {
						count++;
						System.out.println(count);
						newrow = spreadsheet.createRow(count);
						col = 0;
					}
					
					XSSFCell newcell1 = newrow.createCell(col++);
					String keywordContain = documentTableCell.getContent().toString();
					
					if (keywordContain.equals(ReadPropertiesFile.readKeywordProperties("101"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("102"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("103"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("104"))) {
					
						workbook.setSheetName(i, ReadPropertiesFile.readKeywordProperties("100"));
						

					}

					else if (keywordContain.equals(ReadPropertiesFile.readKeywordProperties("201"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("202"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("203"))) {
						
						workbook.setSheetName(i, ReadPropertiesFile.readKeywordProperties("200"));
					}

					else if (keywordContain.equals(ReadPropertiesFile.readKeywordProperties("301"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("302"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("303"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("304"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("305"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("306"))) 
						{
					
						workbook.setSheetName(i, ReadPropertiesFile.readKeywordProperties("300"));

						}

					newcell1.setCellValue(documentTableCell.getContent().toString());

			
				}
				
				for(int c=0; c<sheetcount; c++) {
					if(workbook.getSheetName(i).equals(ReadPropertiesFile.readKeywordProperties("100"))) {

						workbook.setSheetName(i, ReadPropertiesFile.readKeywordProperties("100")+" "+incomeSheetCount++);

					}
					if(workbook.getSheetName(i).equals(ReadPropertiesFile.readKeywordProperties("200"))) {

						workbook.setSheetName(i, ReadPropertiesFile.readKeywordProperties("200")+" "+balanceSheetCount++);

					}
					if(workbook.getSheetName(i).equals(ReadPropertiesFile.readKeywordProperties("300"))) {

						workbook.setSheetName(i, ReadPropertiesFile.readKeywordProperties("300")+" "+cashFlowCount++);

					}
					if(workbook.getSheetName(i).equals("sheet")) {

						workbook.setSheetName(i,"sheet "+sheetcount++);

					}
			}
				System.out.println("=======================Created a new sheet===========================");
			}
		

		
			System.out.printf("Successfully created %d sheets", tables.size());	
		
			
			Connection con=InvestorDatabaseUtill.getConnection();
			TableList tablelist=new TableList();
		
			
	
		
			
			statement= con.prepareStatement(DataIngestionQueryConstant.SELECT_MAX_TABLEID.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
			rs=statement.executeQuery();
			
			while(rs.next())
			{
		           
				long newtableId=rs.getLong(1);
	
		    
				
          
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				XSSFSheet    sheet =workbook.getSheetAt(i);
			
				int keywordcount=0;
				long score=0;
				for(Row row1:sheet)
				{
				for(Cell cell:row1) {
					
					if(cell.getStringCellValue().isEmpty())
					{
						cell.setCellValue("NA");
					}
					
					String keywordContain = cell.getStringCellValue();
					
					
					if(keywordContain.equals(ReadPropertiesFile.readKeywordProperties("101"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("102"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("103"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("104")))
							{
						keywordcount++;
						score=(keywordcount*100/4);
							}
					if(keywordContain.equals(ReadPropertiesFile.readKeywordProperties("201"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("202"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("203")))
					{
						keywordcount++;
						score=(keywordcount*100/3);
					}
					if(keywordContain.equals(ReadPropertiesFile.readKeywordProperties("301"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("302"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("303"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("304"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("305"))
							|| keywordContain.equals(ReadPropertiesFile.readKeywordProperties("306")))
					{
						keywordcount++;
						score=(keywordcount*100/6);
						
					}
					
				}
				}
			
				tablelist.setTableId(newtableId+1);
				long fileId=dataIngestion.getFileId();
				String  Table_name= workbook.getSheetName(i);
				String tablemapName=null;
				
				statement=con.prepareStatement(DataIngestionQueryConstant.INSERT_TABLELIST.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
				statement.setLong(1,fileId);
				statement.setLong(2,tablelist.getTableId());
				statement.setString(3, Table_name);
				statement.setLong(4, score);
				statement.setString(5, tablemapName);
				statement.executeUpdate();

	DataFormatter formatter = new DataFormatter();

			for(Row row1:sheet)
			{
			for(Cell cell:row1) {
				
				if(cell.getStringCellValue().isEmpty())
				{
					cell.setCellValue("NA");
				}
			}			
					String value1 = formatter.formatCellValue(row1.getCell(0)); 
					String value2 = formatter.formatCellValue(row1.getCell(1));
					String value3 = formatter.formatCellValue(row1.getCell(2));
					String value4 = formatter.formatCellValue(row1.getCell(3));
					String value5 = formatter.formatCellValue(row1.getCell(4));
					String value6 = formatter.formatCellValue(row1.getCell(5));
					String value7 = formatter.formatCellValue(row1.getCell(6));
					String value8 = formatter.formatCellValue(row1.getCell(7));
					String value9 = formatter.formatCellValue(row1.getCell(8));
					String value10 = formatter.formatCellValue(row1.getCell(9));
					String value11= formatter.formatCellValue(row1.getCell(10));
					String value12= formatter.formatCellValue(row1.getCell(11));
					String value13 = formatter.formatCellValue(row1.getCell(12));
					String value14 = formatter.formatCellValue(row1.getCell(13));
					String value15 = formatter.formatCellValue(row1.getCell(14));
					String value16 = formatter.formatCellValue(row1.getCell(15));
					String value17 = formatter.formatCellValue(row1.getCell(16));
					String value18 = formatter.formatCellValue(row1.getCell(17));
					String value19 = formatter.formatCellValue(row1.getCell(18));
					String value20 = formatter.formatCellValue(row1.getCell(19));
					String value21 = formatter.formatCellValue(row1.getCell(20));
					String value22 = formatter.formatCellValue(row1.getCell(21));
					String value23 = formatter.formatCellValue(row1.getCell(22));
					String value24 = formatter.formatCellValue(row1.getCell(23));
					String value25 = formatter.formatCellValue(row1.getCell(24));
				
	    
	             statement= con.prepareStatement(DataIngestionQueryConstant.INSERT_INTO_DATAINGESTION_TABLE_DATA.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));	
	             statement.setLong(1,tablelist.getTableId());
					statement.setString(2,value1);
					statement.setString(3, value2);
					statement.setString(4, value3);
					statement.setString(5, value4);
					statement.setString(6, value5);
					statement.setString(7, value6);
					statement.setString(8, value7);
					statement.setString(9, value8);
					statement.setString(10, value9);
					statement.setString(11, value10);
					statement.setString(12, value11);
					statement.setString(13, value12);
					statement.setString(14, value13);
					statement.setString(15, value14);
					statement.setString(16, value15);
					statement.setString(17, value16);
					statement.setString(18, value17);
					statement.setString(19, value18);
					statement.setString(20, value19);
					statement.setString(21, value20);
					statement.setString(22, value21);
					statement.setString(23, value22);
					statement.setString(24, value23);
					statement.setString(25, value24);
					statement.setString(26, value25);
					statement.executeUpdate();	
	             }
			newtableId++;
			}
			}
			
				 
			con.close();
		}
		return null;
		
	
	
}



	@Override
	public ArrayList<TableList> getTableIdByFileId(long fileId, String dataBaseName) throws DataIngestionDaoException {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;
		
		ArrayList<TableList> list=new ArrayList<>();
		try {
			
			connection = InvestorDatabaseUtill.getConnection();
			
			
			pstmt=connection.prepareStatement(DataIngestionQueryConstant.SELECT_TABLEID_BYFILEID.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
			pstmt.setLong(1, fileId);
			
			result=pstmt.executeQuery();
		
			while(result.next())
			{
				TableList model=new TableList();
				model.setTableId(result.getLong("tableId"));
				model.setTableName(result.getString("tableName"));
				model.setScore(result.getLong("score"));
				
				
				list.add(model);
			}
			
			return list;
							
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new DataIngestionDaoException("unable to get"+e.getMessage());
			
		}
		
	
		}



	@Override
	public ArrayList<DataIngestionTableModel> getTableIngestionTableData(long tableId, String dataBaseName) throws DataIngestionDaoException{
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;
		ArrayList<DataIngestionTableModel> list=new ArrayList<>();
		try {
			connection = InvestorDatabaseUtill.getConnection();
			pstmt=connection.prepareStatement(DataIngestionQueryConstant.SELECT_DATAINGESTION_TABLEDETAILS.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
		    pstmt.setLong(1, tableId);
		     result=pstmt.executeQuery();
		     while(result.next())
		     {
		    	 DataIngestionTableModel modeldata=buildData(result);
		    	 
		    	 list.add(modeldata);
		     }
		     return list;
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new DataIngestionDaoException("unable to get"+e.getMessage());
		}
	
	}



	private DataIngestionTableModel buildData(ResultSet result) throws SQLException {
		// TODO Auto-generated method stub
		DataIngestionTableModel modeldata=new DataIngestionTableModel();
		modeldata.setField_Id(result.getLong("field_Id"));
		modeldata.setC1(result.getString("C1"));
		modeldata.setC2(result.getString("C2"));
		modeldata.setC3(result.getString("C3"));
		modeldata.setC4(result.getString("C4"));
		modeldata.setC5(result.getString("C5"));
		modeldata.setC6(result.getString("C6"));
		modeldata.setC7(result.getString("C7"));
		modeldata.setC8(result.getString("C8"));
		modeldata.setC9(result.getString("C9"));
		modeldata.setC10(result.getString("C10"));
		modeldata.setC11(result.getString("C11"));
		modeldata.setC12(result.getString("C12"));
		modeldata.setC13(result.getString("C13"));
		modeldata.setC14(result.getString("C14"));
		modeldata.setC15(result.getString("C15"));
		modeldata.setC16(result.getString("C16"));
		modeldata.setC17(result.getString("C17"));
		modeldata.setC18(result.getString("C18"));
		modeldata.setC19(result.getString("C19"));
		modeldata.setC20(result.getString("C21"));
		modeldata.setC21(result.getString("C21"));
		modeldata.setC22(result.getString("C22"));
		modeldata.setC23(result.getString("C23"));
		modeldata.setC24(result.getString("C24"));
		modeldata.setC25(result.getString("C25"));
		if(result.getString("masterLineItem")==null)
		{
			
			modeldata.setMasterLineItem("NA");
		
		}
		else {
		
	     modeldata.setMasterLineItem(result.getString("masterLineItem"));
		}
		return modeldata;
		
	}
	

	@Override
	public void deleteTableDataByTableId(long tableId, String dataBaseName) throws DataIngestionDaoException {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement pstmt = null;

		try {
			connection = InvestorDatabaseUtill.getConnection();
			pstmt=connection.prepareStatement(DataIngestionQueryConstant.DELETE_TABLEDETAILS_BYTABLEID.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
			pstmt.setLong(1, tableId);
			pstmt.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionDaoException("unable to delete table data");
		}
		finally {
			LOGGER.debug("closing the connections");
			InvestorDatabaseUtill.close(pstmt, connection);
		}
	
		
	}


	@Override
	public ArrayList<DataIngestionTableModel> updatedataIngestionTableData(ArrayList<DataIngestionTableModel> dataIngestionTableData,
			long tableId, String dataBaseName) throws DataIngestionDaoException {
		// TODO Auto-generated method stub
		Connection connection=null;
		PreparedStatement pstmt=null;
		try {
			System.out.println("check2");
       connection=InvestorDatabaseUtill.getConnection();
  	    pstmt=connection.prepareStatement(DataIngestionQueryConstant.UPDATE_DATAINGESTION_TABLEDETAILS.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
   	    Iterator it=dataIngestionTableData.iterator();
   	    while(it.hasNext())
   	    	
   	    {
   	    	DataIngestionTableModel model=(DataIngestionTableModel) it.next();
   	    	
 		   pstmt.setString(1, model.getC1());
 		   pstmt.setString(2, model.getC2());
 		   pstmt.setString(3, model.getC3());
 		   pstmt.setString(4, model.getC4());
 		   pstmt.setString(5, model.getC5());
 		   pstmt.setString(6, model.getC6());
 		   pstmt.setString(7, model.getC7());
 		   pstmt.setString(8, model.getC8());
 		   pstmt.setString(9, model.getC9());
 		   pstmt.setString(10, model.getC10());
 		   pstmt.setString(11, model.getC11());
 		   pstmt.setString(12, model.getC12());
 		   pstmt.setString(13, model.getC13());
 		   pstmt.setString(14, model.getC14());
 		   pstmt.setString(15, model.getC15());
 		   pstmt.setString(16, model.getC16());
 		   pstmt.setString(17, model.getC17());
 		   pstmt.setString(18,model.getC18());
 		   pstmt.setString(19, model.getC19());
 		   pstmt.setString(20, model.getC20());
 		   pstmt.setString(21, model.getC21());
 		   pstmt.setString(22, model.getC22());
 		   pstmt.setString(23, model.getC23());
 		   pstmt.setString(24, model.getC24());
 		   pstmt.setString(25, model.getC25());
 		 
 		   pstmt.setLong(26, model.getField_Id());
   	    
 		   pstmt.executeUpdate();
   	    }
   	    return dataIngestionTableData;
       
		}catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionDaoException("unable to update" +e.getMessage());
		}
		finally {
			LOGGER.debug("closing the connections");
			InvestorDatabaseUtill.close(pstmt, connection);
		}
		
	
	}



	@Override
	public ArrayList<DataIngestionMappingModel> addDataIngestionMappingTableData(
			ArrayList<DataIngestionMappingModel> dataIngestionMappingTable, String dataBaseName) throws DataIngestionDaoException {
		Connection connection = null;
		PreparedStatement psta = null;
		Date date = new Date();
		System.out.println("database name" + dataBaseName);
		try {
			connection = InvestorDatabaseUtill.getConnection();
			psta = connection.prepareStatement(DataIngestionQueryConstant.INSERT_INTO_DATAINGESTION_MAPPINGTABLE
					.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
			Iterator ir=dataIngestionMappingTable.iterator();
			while(ir.hasNext())
			{
				DataIngestionMappingModel dataIngestionModel=(DataIngestionMappingModel) ir.next();
			String mapId = UUID.randomUUID().toString();
			dataIngestionModel.setMapId(mapId);
			psta.setString(1, dataIngestionModel.getMapId());
			psta.setLong(2, dataIngestionModel.getFieldId());
			psta.setString(3, dataIngestionModel.getAnalyst());
			psta.setString(4, dataIngestionModel.getMasterLineItem());
			psta.setString(5, dataIngestionModel.getCompanyName());
			psta.setString(6, dataIngestionModel.getTableName());
			psta.setString(7, dataIngestionModel.getDocumentType());
			psta.setString(8, dataIngestionModel.getYear());
			psta.setString(9, dataIngestionModel.getLineItemName());
			psta.setString(10, dataIngestionModel.getQuarter());
			psta.setString(11, dataIngestionModel.getType());
			psta.setString(12, dataIngestionModel.getValue());
			psta.executeUpdate();
			}
     return dataIngestionMappingTable;
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			throw new DataIngestionDaoException("unable to create data Ingestion mapping table"+e.getMessage());
		} finally {
			LOGGER.info("closing the connection");
			InvestorDatabaseUtill.close(psta, connection);

		}
	}




	
	public DataIngestionTableModel getTableDataByFeldId(long field_Id, String dataBaseName)
			throws DataIngestionDaoException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;
		try
		{
			connection=InvestorDatabaseUtill.getConnection();
			pstmt=connection.prepareStatement(DataIngestionQueryConstant.SELECT_TABLEDATA_BYFIELDID.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
		   pstmt.setLong(1, field_Id);
		 result=pstmt.executeQuery();
		   while(result.next())
		   {
			   DataIngestionTableModel model=new DataIngestionTableModel();
			   model.setField_Id(result.getLong("field_Id"));
			   model.setC1(result.getString("C1"));
			   model.setC2(result.getString("C2"));
			   model.setC3(result.getString("C3"));
			   model.setC4(result.getString("C4"));
			   model.setC5(result.getString("C5"));
			   model.setC6(result.getString("C6"));
			   model.setC7(result.getString("C7"));
			   model.setC8(result.getString("C8"));
			   model.setC9(result.getString("C9"));
			   model.setC10(result.getString("C10"));
			   model.setC11(result.getString("C11"));
			   model.setC12(result.getString("C12"));
			   model.setC13(result.getString("C13"));
			   model.setC14(result.getString("C14"));
			   model.setC15(result.getString("C15"));
			   model.setC16(result.getString("C16"));
			   model.setC17(result.getString("C17"));
				model.setC18(result.getString("C18"));
				model.setC19(result.getString("C19"));
				model.setC20(result.getString("C21"));
				model.setC21(result.getString("C21"));
				model.setC22(result.getString("C22"));
				model.setC23(result.getString("C23"));
				model.setC24(result.getString("C24"));
				model.setC25(result.getString("C25"));
				return model;
		   }
		}
		catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionDaoException("unable to get table data bye fieldId"+e.getMessage());
		}
		finally {
			LOGGER.info("closing the connection");
			InvestorDatabaseUtill.close(pstmt, connection);

		}
		return null;
	}




	@Override
	public void deleteTableDataByFieldId(long field_Id, String dataBaseName) throws DataIngestionDaoException {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement pstmt = null;
		try
		{
			System.out.println("chechk1");
			connection=InvestorDatabaseUtill.getConnection();
			pstmt=connection.prepareStatement(DataIngestionQueryConstant.DELETE_TABLEDATA_BY_FIELDID.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
	    	 pstmt.setLong(1, field_Id);
	    	 pstmt.executeUpdate();
	
		}
		catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionDaoException("unable to delete table data bye fieldId"+e.getMessage());
		}
		finally {
			LOGGER.info("closing the connection");
			InvestorDatabaseUtill.close(pstmt, connection);

		}
		
	}




	@Override
	public TableList updateTableNameByTableId(TableList tabledata,long tableId, String dataBaseName)
			throws DataIngestionDaoException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		try
		{
			connection=InvestorDatabaseUtill.getConnection();
			pstmt=connection.prepareStatement(DataIngestionQueryConstant.UPDATE_TABLENAME_BYTABLEID.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
		  pstmt.setString(1, tabledata.getTableName());
			pstmt.setLong(2, tableId);
		  pstmt.executeUpdate();
		  return tabledata;
		}catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionDaoException("unable to update table name"+e.getMessage());
		}
		finally {
			LOGGER.info("closing the connection");
			InvestorDatabaseUtill.close(pstmt, connection);

		}
		
	}


	@Override
	public String downloadTableDataBytableId(long tableId, String dataBaseName) throws DataIngestionDaoException, IOException {
		// TODO Auto-generated method stub
		   Connection connection = null;
			PreparedStatement psta = null;
			ResultSet rs=null;
			String tableName=null;
	     ArrayList<DataIngestionTableModel> list=new ArrayList<>();
		XSSFWorkbook workbook = new XSSFWorkbook();
		try {
		connection=InvestorDatabaseUtill.getConnection();
		psta=connection.prepareStatement(DataIngestionQueryConstant.SELECT_TABLENAME.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
	     psta.setLong(1, tableId);
	     rs=psta.executeQuery();
	     while(rs.next())
	     {
	    
	    	tableName=rs.getString("tableName"); 
	  
	     }
	   
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	
		String sheetname=tableName;
		
		XSSFSheet sheet=workbook.createSheet(sheetname);
		String wbname=tableName;
		
		    String home=System.getProperty("user.home");
		    
		    final String CSV_LOCATION =(home+"/Downloads/"+wbname+".xlsx");
	         try {
	        	// PrintWriter pw=new PrintWriter(new FileWriter(CSV_LOCATION));
				connection=InvestorDatabaseUtill.getConnection();
				psta=connection.prepareStatement(DataIngestionQueryConstant.SELECT_TABLEDATA_BYTABLEID_DOWNLOAD.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
			psta.setLong(1, tableId);
			rs=psta.executeQuery();
			int rownum=1;
			
			XSSFRow row1=sheet.createRow(0);
			row1.createCell(0).setCellValue("field_Id");
			row1.createCell(1).setCellValue("tableId");
			row1.createCell(2).setCellValue("C1");
			row1.createCell(3).setCellValue("C2");
			row1.createCell(4).setCellValue("C3");
			row1.createCell(5).setCellValue("C4");
			row1.createCell(6).setCellValue("C5");
			row1.createCell(7).setCellValue("C6");
			row1.createCell(8).setCellValue("C7");
			row1.createCell(9).setCellValue("C8");
			row1.createCell(10).setCellValue("C9");
			row1.createCell(11).setCellValue("C10");
			row1.createCell(12).setCellValue("C11");
			row1.createCell(13).setCellValue("C12");
			row1.createCell(14).setCellValue("C13");
			row1.createCell(15).setCellValue("C14");
			row1.createCell(16).setCellValue("C15");
			row1.createCell(17).setCellValue("C16");
			row1.createCell(18).setCellValue("C17");
			row1.createCell(19).setCellValue("C18");
			row1.createCell(20).setCellValue("C19");
			row1.createCell(21).setCellValue("C20");
			row1.createCell(22).setCellValue("C21");
			row1.createCell(23).setCellValue("C22");
			row1.createCell(24).setCellValue("C23");
			row1.createCell(25).setCellValue("C24");
			row1.createCell(26).setCellValue("C25");
		
			while(rs.next())
			{	
				int colnum=0;
				XSSFRow row=sheet.createRow(rownum);
				 row=sheet.createRow(rownum++);
				row.createCell(colnum++).setCellValue(rs.getLong("field_Id"));
				row.createCell(colnum++).setCellValue(rs.getLong("tableId"));
				row.createCell(colnum++).setCellValue(rs.getString("C1"));
				row.createCell(colnum++).setCellValue(rs.getString("C2"));
				row.createCell(colnum++).setCellValue(rs.getString("C3"));
				row.createCell(colnum++).setCellValue(rs.getString("C4"));
				row.createCell(colnum++).setCellValue(rs.getString("C5"));
				row.createCell(colnum++).setCellValue(rs.getString("C6"));
				row.createCell(colnum++).setCellValue(rs.getString("C7"));
				row.createCell(colnum++).setCellValue(rs.getString("C8"));
				row.createCell(colnum++).setCellValue(rs.getString("C9"));
				row.createCell(colnum++).setCellValue(rs.getString("C10"));
				row.createCell(colnum++).setCellValue(rs.getString("C11"));
				row.createCell(colnum++).setCellValue(rs.getString("C12"));
				row.createCell(colnum++).setCellValue(rs.getString("C13"));
				row.createCell(colnum++).setCellValue(rs.getString("C14"));
				row.createCell(colnum++).setCellValue(rs.getString("C15"));
				row.createCell(colnum++).setCellValue(rs.getString("C16"));
				row.createCell(colnum++).setCellValue(rs.getString("C17"));
				row.createCell(colnum++).setCellValue(rs.getString("C18"));
				row.createCell(colnum++).setCellValue(rs.getString("C19"));
				row.createCell(colnum++).setCellValue(rs.getString("C20"));
				row.createCell(colnum++).setCellValue(rs.getString("C21"));
				row.createCell(colnum++).setCellValue(rs.getString("C22"));
				row.createCell(colnum++).setCellValue(rs.getString("C23"));
				row.createCell(colnum++).setCellValue(rs.getString("C24"));
				row.createCell(colnum++).setCellValue(rs.getString("C25"));

				//write data in csv file
//				pw.println(model.getField_Id()+","+model.getC1()+","+model.getC2()+","+model.getC3());
//				//pw.println(rs.getString(3)+rs.getString(4)+rs.getString(5)+rs.getString(6)+
//					//	rs.getString(6)+rs.getString(8)+rs.getString(9)+rs.getString(10));
//				list.add(model);
			}
			
			
			FileOutputStream file=new FileOutputStream(CSV_LOCATION);
			workbook.write(file);
			
		workbook.close();
	   return "download file successfully";
			 }
	         catch (Exception e) {
				// TODO: handle exception
			}
			return null;
	
		
			
	
	}

	




	@Override
	public ArrayList<DataIngestionModel> getfileDetails(String dataBaseName) throws DataIngestionDaoException {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement psta = null;
		ResultSet rs=null;
		ArrayList<DataIngestionModel> list=new ArrayList<>();
	   try {
		   connection=InvestorDatabaseUtill.getConnection();
		   psta=connection.prepareStatement(DataIngestionQueryConstant.SELECT_DATAINGESTION_FILEDETAILS.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
	    rs=psta.executeQuery();
	    while(rs.next())
	    {
	    	DataIngestionModel model=new DataIngestionModel();
	    	model.setFileId(rs.getLong("fileId"));
	    	model.setClient(rs.getString("client"));
	    	model.setDocumentType(rs.getString("documentType"));
	    	model.setAnalystName(rs.getString("analystName"));
	    	model.setReportFrom(rs.getDate("reportFrom"));
	    	model.setReportTo(rs.getDate("reportTo"));
	    	model.setFileName(rs.getString("fileName"));
	    	model.setFileType(rs.getString("fileType"));
	    	model.setFileData(rs.getBytes("fileData"));
	    	list.add(model);
	    }
	    return list;
	       
	   }
	   catch (Exception e) {
		// TODO: handle exception
			throw new DataIngestionDaoException("unable to update table name"+e.getMessage());
	}
	}




	@Override
	public ArrayList<KeywordList> getKeyword(String dataBaseName) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs=null;
		ArrayList<KeywordList> list=new ArrayList<>();
		try
		{
			connection=InvestorDatabaseUtill.getConnection();
			pstmt=connection.prepareStatement(DataIngestionQueryConstant.SELECT_KEYWORD.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));
	      rs=pstmt.executeQuery();
	      
	      while(rs.next())
	      {
	    	  KeywordList keyowrd=new KeywordList();
	    	  keyowrd.setKey_id(rs.getLong("key_id"));
	    	  keyowrd.setDocument_type(rs.getString("document_type"));
	    	  keyowrd.setKeyword(rs.getString("keyword"));
	    	  keyowrd.setWeight(rs.getInt("weight"));
	    	  list.add(keyowrd);
	      }
	      return list;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;


	}




	@Override
	public String uploadExcelSheet(CompletedFileUpload file, long tableId, String dataBaseName) {
		// TODO Auto-generated method stub
		Connection connection = null;
		PreparedStatement statement = null;
		
		try
		
		{	
		
			byte[] fileContent=file.getBytes();
		
			InputStream targetStream = new ByteArrayInputStream(fileContent);
		
		
			XSSFWorkbook workbook=new XSSFWorkbook(targetStream);  
		
		
			XSSFSheet sheet=workbook.getSheetAt(0); 
			DataFormatter formatter = new DataFormatter();
		
			int rownum=0;
			 for(Row row1:sheet)
			{
				 
				 if(rownum==0)
				 {
					 
					 rownum++;
					 continue;
				 }

						
						   String id = formatter.formatCellValue(row1.getCell(0));
						
						   long field_id=Long.parseLong(id);
						
							String value2 = formatter.formatCellValue(row1.getCell(2));
							String value3 = formatter.formatCellValue(row1.getCell(3));
							String value4 = formatter.formatCellValue(row1.getCell(4));
							String value5 = formatter.formatCellValue(row1.getCell(5));
							String value6 = formatter.formatCellValue(row1.getCell(6));
							String value7 = formatter.formatCellValue(row1.getCell(7));
							String value8 = formatter.formatCellValue(row1.getCell(8));
							String value9 = formatter.formatCellValue(row1.getCell(9));
							String value10 = formatter.formatCellValue(row1.getCell(10));
							String value11 = formatter.formatCellValue(row1.getCell(11));
							String value12= formatter.formatCellValue(row1.getCell(12));
							String value13= formatter.formatCellValue(row1.getCell(13));
							String value14 = formatter.formatCellValue(row1.getCell(14));
							String value15 = formatter.formatCellValue(row1.getCell(15));
							String value16 = formatter.formatCellValue(row1.getCell(16));
							String value17 = formatter.formatCellValue(row1.getCell(17));
							String value18 = formatter.formatCellValue(row1.getCell(18));
							String value19 = formatter.formatCellValue(row1.getCell(19));
							String value20 = formatter.formatCellValue(row1.getCell(20));
							String value21 = formatter.formatCellValue(row1.getCell(21));
							String value22 = formatter.formatCellValue(row1.getCell(22));
							String value23 = formatter.formatCellValue(row1.getCell(23));
							String value24 = formatter.formatCellValue(row1.getCell(24));
							String value25 = formatter.formatCellValue(row1.getCell(25));
							String value26 = formatter.formatCellValue(row1.getCell(26));
						
							connection=InvestorDatabaseUtill.getConnection();
			             statement= connection.prepareStatement(DataIngestionQueryConstant.UPDATE_DATAINGESTION_TABLEDETAILS.replace(DataIngestionQueryConstant.DATA_BASE_PLACE_HOLDER, dataBaseName));	
							statement.setString(1, value2);
							statement.setString(2, value3);
							statement.setString(3, value4);
							statement.setString(4, value5);
							statement.setString(5, value6);
							statement.setString(6, value7);
							statement.setString(7, value8);
							statement.setString(8, value9);
							statement.setString(9, value10);
							statement.setString(10, value11);
							statement.setString(11, value12);
							statement.setString(12, value13);
							statement.setString(13, value14);
							statement.setString(14, value15);
							statement.setString(15, value16);
							statement.setString(16, value17);
							statement.setString(17, value18);
							statement.setString(18, value19);
							statement.setString(19, value20);
							statement.setString(20, value21);
							statement.setString(21, value22);
							statement.setString(22, value23);
							statement.setString(23, value24);
							statement.setString(24, value25);
							statement.setString(25, value26);
							statement.setLong(26, field_id);
							statement.executeUpdate();	
						
						
						    rownum++;
						    System.out.println("rownumber"+rownum);
					     
		  
			}
		
					
			
     return "update done";
			
	}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;





	}
}
	








		
	




