package com.Anemoi.InvestorRelation.DataIngestion;

import java.util.ArrayList;

import com.Anemoi.InvestorRelation.CashFlow.CashFlowControllerException;
import com.Anemoi.InvestorRelation.Configuration.ReadPropertiesFile;

import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Delete;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Patch;
import io.micronaut.http.annotation.PathVariable;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.multipart.CompletedFileUpload;
import jakarta.inject.Inject;

@Controller("/investor/dataIngestion")
public class DataIngestionController {

	
	@Inject
	DataIngestionService dataingestionService;
	

	@Post(uri = "/addDataIngestion", consumes = { MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public HttpResponse<DataIngestionModel> saveDataIngetion(@Body DataIngestionModel dataIngestionModel,
			CompletedFileUpload file) throws DataIngestionControllerException

	{
		
		try {
			System.out.println(file.getFilename()+"******************");
			DataIngestionModel dataingestionObject = this.dataingestionService.saveDataIngestion(dataIngestionModel,
					file);
			return HttpResponse.status(HttpStatus.OK).body(dataingestionObject);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,
					e.getMessage());
		}
	}
	
	@Get("/getdataingestionFileData")
	public ArrayList<DataIngestionModel> getDataIngestionFileDetails() throws DataIngestionControllerException
	{
		try
		{
			ArrayList<DataIngestionModel> list=this.dataingestionService.getfileDetails();
			return list;
		}
		catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,
					e.getMessage());
		}
	}
	
			
	
	@Get("/file/{fileId}")
	public ArrayList<TableList> getTableId(@PathVariable("fileId") long fileId)
			throws DataIngestionControllerException {
		
		try {
			ArrayList<TableList> tableid = this.dataingestionService.getTableIdByFileId(fileId);
			return tableid;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,
					e.getMessage());
		}

	}

	@Get("/table/{tableId}")
	public ArrayList<DataIngestionTableModel> getDataIngestionTableDetails(@PathVariable("tableId") long tableId)
			throws DataIngestionControllerException {
		try {
			ArrayList<DataIngestionTableModel> tableData = this.dataingestionService.getDataIngestionTableDetails(tableId);
			return tableData;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,
					e.getMessage());
		}

	}
	
	@Delete("/deleteDataByTableId/{tableId}")
	public String deleteTableDataByTableId(@PathVariable("tableId") long tableId) throws DataIngestionControllerException
	{
		try
		{
			String response=this.dataingestionService.deleteTableDatabyTableID(tableId);
			return response;
		}
		catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,e.getMessage());
		}
	}

	
	@Get("/getTableDataByFieldId/{field_Id}")
	public DataIngestionTableModel getTableDataByFieldId(@PathVariable("field_Id") long field_Id) throws DataIngestionControllerException
	{
		try
		{
			DataIngestionTableModel model=this.dataingestionService.getTableDataByFieldId(field_Id);
			return model;
			
		}
		catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,e.getMessage());
		}
	}
	
	@Delete("/deleteTableDataByfieldId/{field_Id}")
	public String deleteTableDataByfieldId(@PathVariable("field_Id") long field_Id) throws DataIngestionControllerException
	{
		try
		{
			System.out.println("check1");
			String response=this.dataingestionService.deleteTableDataByFieldId(field_Id);
			return response;
		}
		catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,e.getMessage());
		}
	}

	
	@Patch("/updateTableName/{tableId}")
	public TableList updateTableNameByTableId(TableList tabledata,@PathVariable("tableId") long tableId) throws DataIngestionControllerException
	{
		try
		{
			TableList model=this.dataingestionService.updateTableNameByTableId(tabledata,tableId);
			return model;
			
		}catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,e.getMessage());
		}
	}
	

	@Patch("/update/{tableId}")
	public ArrayList<DataIngestionTableModel> updateDataIngestionTableData(
			@Body ArrayList<DataIngestionTableModel> dataIngestionTableData, @PathVariable("tableId") long tableId)
			throws DataIngestionControllerException {

		try {
			ArrayList<DataIngestionTableModel> response = this.dataingestionService
					.updateeDataIngestionTabledata(dataIngestionTableData, tableId);
			return response;
		} catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,
					e.getMessage());
		}

	}
	
	
	@Get("/downloadTableData/{tableId}")
	public String  downloadTableDataByTableId(@PathVariable("tableId") long tableId) throws DataIngestionControllerException
	{
	
		try {
		String response=this.dataingestionService.downloadTableDataByTableId(tableId);
		return response;
		
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	@Patch(uri="/uploadExcelSheet/{tableId}", consumes = { MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	public String uploadExcelsheetByTableId(@PathVariable long tableId,CompletedFileUpload file)
	{
		try {
			System.out.println("check1");
			String response=this.dataingestionService.uploadExcelSheetBytableId(file,tableId);
			return response;
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
		
	}
	
	/////// Data Ingestion Mapping table API
	@Post("/addDataIngestionMappingTableDetails")
	public ArrayList<DataIngestionMappingModel> addDataIngestionMappingDetails(
			@Body ArrayList<DataIngestionMappingModel> dataIngestionMappingTable)
			throws DataIngestionControllerException {
		try {
			ArrayList<DataIngestionMappingModel> mappingTable = this.dataingestionService
					.addDataIngestionMappingTable(dataIngestionMappingTable);
			return mappingTable;
		} catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionControllerException(ReadPropertiesFile.readResponseProperty("101"), e, 400,
					e.getMessage());
		}
	}
	
	@Get("/getkeyword")
	public ArrayList<KeywordList> getKeyword()
	{
		ArrayList<KeywordList> list=this.dataingestionService.getKeyword();
		return list;
	}


	
}
