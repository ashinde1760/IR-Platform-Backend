package com.Anemoi.InvestorRelation.DataIngestion;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;

import com.Anemoi.InvestorRelation.Configuration.ReadPropertiesFile;

import io.micronaut.http.multipart.CompletedFileUpload;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Singleton
public class DataIngestionServiceImpl implements DataIngestionService {
	
	@Inject
	DataIngestionDao dataIngestionDao;
	
	private static final Object STATUS = "status";
	private static final Object SUCCESS = "success";
	private static final Object MSG = "msg";

	
private static String DATABASENAME="databaseName";
	
	private static String dataBaseName() {
		
		List<String>tenentList= ReadPropertiesFile.getAllTenant();
		for(String tenent : tenentList) {
			 DATABASENAME = ReadPropertiesFile.dataBaseName(tenent);
		}
		return DATABASENAME;
		
	}

	@Override
	public DataIngestionModel saveDataIngestion(DataIngestionModel dataIngestionModel, CompletedFileUpload file) throws DataIngestionServiceException {
		// TODO Auto-generated method stub
		String dataBaseName=DataIngestionServiceImpl.dataBaseName();
		try {
			//DataIngestionModel model=new DataIngestionModel();
			String fileName=file.getFilename();
			String fileType=file.getContentType().toString();
			byte[] fileData=file.getBytes();
			
			dataIngestionModel.setFileName(fileName);
			
			dataIngestionModel.setFileType(fileType);
			dataIngestionModel.setFileData(fileData);
			
			DataIngestionModel dataIngestion=this.dataIngestionDao.saveDataIngestionDetails(dataIngestionModel,dataBaseName);
		  this.dataIngestionDao.saveDataIngestionInDataBase(dataIngestion,dataBaseName);
			return dataIngestion;
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new DataIngestionServiceException("unable to create"+e.getMessage());
		}
	
	
	}

	@Override
	public ArrayList<TableList> getTableIdByFileId(long fileId) throws DataIngestionServiceException {
		// TODO Auto-generated method stub
		
	try {
		String dataBaseName=DataIngestionServiceImpl.dataBaseName();
		ArrayList<TableList> tableid=this.dataIngestionDao.getTableIdByFileId(fileId,dataBaseName);
		return tableid;
	}
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		throw new DataIngestionServiceException("unable ot get"+e.getMessage());
	}

	}

	@Override
	public ArrayList<DataIngestionTableModel> getDataIngestionTableDetails(long tableId) throws DataIngestionServiceException {
		// TODO Auto-generated method stub
	  try
	   {
		String dataBaseName=DataIngestionServiceImpl.dataBaseName();
		ArrayList<DataIngestionTableModel> tableData=this.dataIngestionDao.getTableIngestionTableData(tableId,dataBaseName);
	   return tableData;
	   }catch (Exception e) {
		// TODO: handle exception
		   e.printStackTrace();
		   throw new DataIngestionServiceException("unable to get"+e.getMessage());
	}

	}
	
	@SuppressWarnings("unchecked")
	@Override
	public String deleteTableDatabyTableID(long tableId) throws DataIngestionServiceException {
		// TODO Auto-generated method stub
		try
		{
			String dataBaseName=DataIngestionServiceImpl.dataBaseName();
		      ArrayList<DataIngestionTableModel> tableData=this.dataIngestionDao.getTableIngestionTableData(tableId, dataBaseName);
		      if(tableData==null)
		      {
		    	  JSONObject reposneJSON = new JSONObject();
					reposneJSON.put(STATUS, SUCCESS);
					reposneJSON.put(MSG, "table not delete because table is null");
		      }
		      this.dataIngestionDao.deleteTableDataByTableId(tableId,dataBaseName);
		      JSONObject reposneJSON = new JSONObject();
				reposneJSON.put(STATUS, SUCCESS);
				reposneJSON.put(MSG, "table data deleted suucessfully");
				return reposneJSON.toString();
						
		}catch (Exception e) {
			// TODO: handle exception
			throw new DataIngestionServiceException("unable to delete table data");
		}
	
	}


	
	

@Override
public ArrayList<DataIngestionTableModel> updateeDataIngestionTabledata(ArrayList<DataIngestionTableModel> dataIngestionTableData, long tableId)
		throws DataIngestionServiceException {
	try
	{System.out.println("check1");
		String dataBaseName=DataIngestionServiceImpl.dataBaseName();
		ArrayList<DataIngestionTableModel> response=this.dataIngestionDao.updatedataIngestionTableData(dataIngestionTableData,tableId,dataBaseName);
	   return response;
	}
	catch (Exception e) {
		// TODO: handle exception
		throw new DataIngestionServiceException("unable to update dataIngestion table data "+e.getMessage());
	}
}


@Override
public ArrayList<DataIngestionMappingModel> addDataIngestionMappingTable(ArrayList<DataIngestionMappingModel> dataIngestionMappingTable) throws DataIngestionServiceException {
	// TODO Auto-generated method stub
    try
    {
    	String dataBaseName=DataIngestionServiceImpl.dataBaseName();
    	ArrayList<DataIngestionMappingModel> mappingModel=this.dataIngestionDao.addDataIngestionMappingTableData(dataIngestionMappingTable,dataBaseName);
         return mappingModel;
    
    }
    catch (Exception e) {
		// TODO: handle exception
    	throw new DataIngestionServiceException("unable to add dataingestion mapping data in table "+e.getMessage());
	}
}

@Override
public DataIngestionTableModel getTableDataByFieldId(long field_Id) throws DataIngestionServiceException
{

  try
  {
	  String dataBaseName=DataIngestionServiceImpl.dataBaseName();
	  DataIngestionTableModel  model=this.dataIngestionDao.getTableDataByFeldId(field_Id,dataBaseName);
	  return model;
	
	  
  }
  catch (Exception e) {
	// TODO: handle exception
	  throw new DataIngestionServiceException("unable to get dataingestion table field data "+e.getMessage());
}
}

@SuppressWarnings("unchecked")
@Override
public String deleteTableDataByFieldId(long field_Id) throws DataIngestionServiceException {

    try
    {
    	String dataBaseName=DataIngestionServiceImpl.dataBaseName();
    	DataIngestionTableModel modelData=this.dataIngestionDao.getTableDataByFeldId(field_Id, dataBaseName);
    	if(modelData==null) {
    		
    		JSONObject reposneJSON = new JSONObject();
			reposneJSON.put(STATUS, SUCCESS);
			reposneJSON.put(MSG, "data not delete because fieldId is null");
    	}
    	this.dataIngestionDao.deleteTableDataByFieldId(field_Id,dataBaseName);
    	 JSONObject reposneJSON = new JSONObject();
			reposneJSON.put(STATUS, SUCCESS);
			reposneJSON.put(MSG, "table field  deleted suucessfully");
			return reposneJSON.toString();
    }catch (Exception e) {
		// TODO: handle exception
    	  throw new DataIngestionServiceException("unable to delete "+e.getMessage());
	}
}

@Override
public TableList updateTableNameByTableId(TableList tabledata,long tableId) throws DataIngestionServiceException {
	// TODO Auto-generated method stub

      try
      {
    	  String dataBaseName=DataIngestionServiceImpl.dataBaseName();
    	  TableList model=this.dataIngestionDao.updateTableNameByTableId(tabledata,tableId,dataBaseName);
    	  return model;
      }
      catch (Exception e) {
		// TODO: handle exception
    	  throw new DataIngestionServiceException("unable to update "+e.getMessage());
	}
}

@Override
public String downloadTableDataByTableId(long tableId) throws DataIngestionServiceException {
   try
   {
	   System.out.println("check2");
	   String dataBaseName=DataIngestionServiceImpl.dataBaseName();
	   String response=this.dataIngestionDao.downloadTableDataBytableId(tableId,dataBaseName);
	   return response;
   }
   catch (Exception e) {
	// TODO: handle exception
	   throw new DataIngestionServiceException("unable to download  "+e.getMessage());
}
     
}

@Override
public ArrayList<DataIngestionModel> getfileDetails() throws DataIngestionServiceException {
	// TODO Auto-generated method stub

      try
      {
    	  String dataBaseName=DataIngestionServiceImpl.dataBaseName();
    	  ArrayList<DataIngestionModel> list=this.dataIngestionDao.getfileDetails(dataBaseName);
    	  return list;
      }
      catch (Exception e) {
		// TODO: handle exception
    	  throw new DataIngestionServiceException("unableto get  "+e.getMessage());
	}
}

@Override
public ArrayList<KeywordList> getKeyword() {
	// TODO Auto-generated method stub
	
	String dataBaseName=DataIngestionServiceImpl.dataBaseName();
	ArrayList<KeywordList> list=this.dataIngestionDao.getKeyword(dataBaseName);
	return list;
}

@Override
public String uploadExcelSheetBytableId(CompletedFileUpload file, long tableId) {

  try
  {
	  System.out.println("check2");
	  String dataBaseName=DataIngestionServiceImpl.dataBaseName();
	  String response=this.dataIngestionDao.uploadExcelSheet(file,tableId,dataBaseName);
	  return response;
  }
  catch (Exception e) {
	// TODO: handle exception
	  e.printStackTrace();
}
return null;
}



}
