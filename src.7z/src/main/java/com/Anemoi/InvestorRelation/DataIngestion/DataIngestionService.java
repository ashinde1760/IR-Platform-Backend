package com.Anemoi.InvestorRelation.DataIngestion;

import java.util.ArrayList;

import io.micronaut.http.multipart.CompletedFileUpload;

public interface DataIngestionService {
	
	
	public DataIngestionModel saveDataIngestion(DataIngestionModel dataIngestionModel,CompletedFileUpload file) throws DataIngestionServiceException;

	
	public ArrayList<TableList> getTableIdByFileId(long fileId) throws DataIngestionServiceException;
	
	
	public ArrayList<DataIngestionTableModel> getDataIngestionTableDetails(long tableId) throws DataIngestionServiceException;

	
	public ArrayList<DataIngestionTableModel> updateeDataIngestionTabledata(ArrayList<DataIngestionTableModel> dataIngestionTableData,
			long tableId) throws DataIngestionServiceException;

	public String deleteTableDatabyTableID(long tableId) throws DataIngestionServiceException;


	//DataIngestion Mapping table 
	public ArrayList<DataIngestionMappingModel> addDataIngestionMappingTable(ArrayList<DataIngestionMappingModel> dataIngestionMappingTable) throws DataIngestionServiceException;


	public DataIngestionTableModel getTableDataByFieldId(long field_Id) throws DataIngestionServiceException;


	public String deleteTableDataByFieldId(long field_Id) throws DataIngestionServiceException;


	public TableList updateTableNameByTableId(TableList tabledata,long tableId) throws DataIngestionServiceException;


	public String downloadTableDataByTableId(long tableId) throws DataIngestionServiceException;


	public ArrayList<DataIngestionModel> getfileDetails() throws DataIngestionServiceException;


	public ArrayList<KeywordList> getKeyword();


	public String uploadExcelSheetBytableId(CompletedFileUpload file, long tableId);




	
	

	
}
