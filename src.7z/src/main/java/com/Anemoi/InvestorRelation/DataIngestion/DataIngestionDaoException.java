package com.Anemoi.InvestorRelation.DataIngestion;

public class DataIngestionDaoException extends Exception {
	private static final long  SerialVertionUID=1L;

	public DataIngestionDaoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DataIngestionDaoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public DataIngestionDaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DataIngestionDaoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DataIngestionDaoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

	
}
