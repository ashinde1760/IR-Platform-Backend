package com.Anemoi.InvestorRelation.DataIngestion;

public class DataIngestionQueryConstant {

	
public static final String DATA_BASE_PLACE_HOLDER = "#$DataBaseName#$";
	
 //   public static final String INGESTIONID = "fileId";
	
	public static final String CLIENT = "client";
	
	public static final String DOCUMENTTYPE="documentType";
	
	public static final String ANALYST="analystName";
	
	public static final String REPORTFROM="reportFrom";
	
	public static final String REPORTTO="reportTo";
	
	public static final String FILENAME="fileName";
	
	public static final String FILETYPE ="fileType";
	
	
	 public static final String INSERT_INTO_DATA_INGESTION="INSERT INTO #$DataBaseName#$.dbo.dataIngestion values(?,?,?,?,?,?,?,?,?)";
	 
	 public static final String SELECT_DATAINGESTION_FILEDETAILS="SELECT * FROM #$DataBaseName#$.dbo.dataIngestion";
	 
	 public static final String SELECT_DATAINGESTION_BYFILEID="SELECT * FROM #$DataBaseName#$.dbo.dataIngestion where fileId=?";
	
	 public static final String SELECT_MAX_FILEID="select MAX(fileId) from #$DataBaseName#$.dbo.dataIngestion";
	 
	public static final String SELECT_TABLENAME="SELECT tableName from #$DataBaseName#$.dbo.tableList where tableId=?";
	
	 public static final String INSERT_TABLELIST="INSERT INTO #$DataBaseName#$.dbo.tableList values(?,?,?,?,?)";
	 
	 public static final String SELECT_TABLEID="SELECT * FROM #$DataBaseName#$.dbo.tableList";
	 
	 // DataIngestion Table queries
	 
	 public static final String INSERT_INTO_DATAINGESTION_TABLE_DATA="INSERT INTO #$DataBaseName#$.dbo.dataIngestionaTabelMetaData values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String SELECT_TABLEID_BYFILEID="SELECT DISTINCT tableId,tableName,score from #$DataBaseName#$.dbo.tableList where fileId=?";
	
	public static final String SELECT_MAX_SCORE="SELECT MAX(score) FROM #$DataBaseName#$.dbo.dataIngestionaTabelMetaData WHERE tableId=?";
	
	public static final String SELECT_DATAINGESTION_TABLEDETAILS="select #$DataBaseName#$.dbo.dataIngestionaTabelMetaData.*,#$DataBaseName#$.dbo.analystLineItem.lineItemName AS masterLineItem from #$DataBaseName#$.dbo.dataIngestionaTabelMetaData full outer join #$DataBaseName#$.dbo.analystLineItem on #$DataBaseName#$.dbo.dataIngestionaTabelMetaData.C1=#$DataBaseName#$.dbo.analystLineItem.analystLineItemName where tableId=?";
			                                              
	public static final String DELETE_TABLEDETAILS_BYTABLEID="DELETE #$DataBaseName#$.dbo.tableList WHERE tableId=?";
	
    public static final String UPDATE_DATAINGESTION_TABLEDETAILS="UPDATE #$DataBaseName#$.dbo.dataIngestionaTabelMetaData  SET C1=?,C2=?,C3=?,C4=?,C5=?,C6=?,C7=?,C8=?,C9=?,C10=?,C11=?,C12=?,C13=?,C14=?,C15=?,C16=?,C17=?,C18=?,C19=?,C20=?,C21=?,C22=?,C23=?,C24=?,C25=? WHERE field_Id=?";

    public static final String SELECT_MAX_TABLEID="select MAX(tableId) from #$DataBaseName#$.dbo.tableList";
   
    public static final String SELECT_TABLEDATA_BYFIELDID="SELECT * FROM #$DataBaseName#$.dbo.dataIngestionaTabelMetaData WHERE field_Id=?";
    
    public static final String DELETE_TABLEDATA_BY_FIELDID="DELETE #$DataBaseName#$.dbo.dataIngestionaTabelMetaData WHERE field_Id=?";
    
     public static final String UPDATE_TABLENAME_BYTABLEID="UPDATE #$DataBaseName#$.dbo.tableList SET tableName=? where tableId=?";
    
     public static final String SELECT_KEYWORD="SELECT * FROM #$DataBaseName#$.dbo.keywordlist";
     
     public static final String SELECT_TABLEDATA_BYTABLEID_DOWNLOAD="SELECT * FROM #$DataBaseName#$.dbo.dataIngestionaTabelMetaData WHERE tableId=?";
     //  DataIngestion Mapping table queries
   
    public static final String INSERT_INTO_DATAINGESTION_MAPPINGTABLE="INSERT INTO #$DataBaseName#$.dbo.dataIngestionMappingtable values(?,?,?,?,?,?,?,?,?,?,?,?)";
    
}
