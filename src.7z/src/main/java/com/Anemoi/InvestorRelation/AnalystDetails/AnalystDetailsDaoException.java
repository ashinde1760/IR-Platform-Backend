package com.Anemoi.InvestorRelation.AnalystDetails;

public class AnalystDetailsDaoException  extends Exception{
	private static final long serialVirsionUID=1L;

	public AnalystDetailsDaoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AnalystDetailsDaoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public AnalystDetailsDaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AnalystDetailsDaoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AnalystDetailsDaoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
