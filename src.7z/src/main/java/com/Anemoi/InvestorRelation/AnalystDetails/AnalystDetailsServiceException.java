package com.Anemoi.InvestorRelation.AnalystDetails;

public class AnalystDetailsServiceException extends Exception {

	private static final long serialVirsionUID=1L;

	public AnalystDetailsServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AnalystDetailsServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public AnalystDetailsServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AnalystDetailsServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AnalystDetailsServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
