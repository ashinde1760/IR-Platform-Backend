package com.Anemoi.InvestorRelation.AnalystLineItem;

public class AnalystLineItemServiceException extends Exception{
	
	private static final long serialVirsionUID=1L;

	public AnalystLineItemServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AnalystLineItemServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public AnalystLineItemServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AnalystLineItemServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AnalystLineItemServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
