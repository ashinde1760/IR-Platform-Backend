package com.Anemoi.InvestorRelation.AnalystLineItem;

public class AnalystLineItemDaoException extends Exception {
	private static final long serialVirsionUID=1L;

	public AnalystLineItemDaoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AnalystLineItemDaoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public AnalystLineItemDaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AnalystLineItemDaoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AnalystLineItemDaoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
