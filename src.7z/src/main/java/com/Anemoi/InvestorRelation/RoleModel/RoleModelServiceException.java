package com.Anemoi.InvestorRelation.RoleModel;

public class RoleModelServiceException extends Exception
{
	private static final long SerialVersionUID=1L;

	public RoleModelServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RoleModelServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public RoleModelServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RoleModelServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RoleModelServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
}
