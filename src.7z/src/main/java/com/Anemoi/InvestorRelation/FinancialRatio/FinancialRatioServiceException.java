package com.Anemoi.InvestorRelation.FinancialRatio;

public class FinancialRatioServiceException extends Exception {

	private static final long  SerialVertionUID=1L;

	public FinancialRatioServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FinancialRatioServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FinancialRatioServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FinancialRatioServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FinancialRatioServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
