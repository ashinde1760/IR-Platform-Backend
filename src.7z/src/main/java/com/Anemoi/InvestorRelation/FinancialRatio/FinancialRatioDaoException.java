package com.Anemoi.InvestorRelation.FinancialRatio;

public class FinancialRatioDaoException extends Exception
{
	private static final long  SerialVertionUID=1L;

	public FinancialRatioDaoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FinancialRatioDaoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FinancialRatioDaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FinancialRatioDaoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FinancialRatioDaoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
}
