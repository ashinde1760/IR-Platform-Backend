package com.Anemoi.InvestorRelation.BalanceSheet;

public class BalanceSheetServiceException extends Exception{
	
	private static final long SerialVertionUID=1L;

	public BalanceSheetServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BalanceSheetServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public BalanceSheetServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BalanceSheetServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BalanceSheetServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
