package com.Anemoi.InvestorRelation.BalanceSheet;

public class BalanceSheetDaoException extends Exception {
	
	private static final long serialVersionUID=1L;

	public BalanceSheetDaoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BalanceSheetDaoException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public BalanceSheetDaoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BalanceSheetDaoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BalanceSheetDaoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
